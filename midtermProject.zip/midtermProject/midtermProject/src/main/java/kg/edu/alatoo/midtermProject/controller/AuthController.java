package kg.edu.alatoo.midtermProject.controller;

import javax.persistence.*;
import jakarta.validation.Valid;

import kg.edu.alatoo.midtermProject.entity.User;
import kg.edu.alatoo.midtermProject.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @Autowired
    private BookRepository bookRepository;

    @GetMapping("/login")
    public String loginPage(@Valid User user) {
        if(user.getRoles().equals("ADMIN")){
            return "/";
        }
        return "/login";
    }
}