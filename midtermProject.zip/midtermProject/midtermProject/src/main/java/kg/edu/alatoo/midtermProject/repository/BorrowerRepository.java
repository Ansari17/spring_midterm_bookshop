package kg.edu.alatoo.midtermProject.repository;

import kg.edu.alatoo.midtermProject.entity.Borrower;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BorrowerRepository extends JpaRepository<Borrower, Long> {

}
