package kg.edu.alatoo.midtermProject.service.impl;

import java.util.List;

import kg.edu.alatoo.midtermProject.entity.Borrower;
import kg.edu.alatoo.midtermProject.repository.BorrowerRepository;
import kg.edu.alatoo.midtermProject.service.BorrowerService;
import org.springframework.stereotype.Service;


@Service
public class BorrowerServiceImpl implements BorrowerService {

    private BorrowerRepository borrowerRepository;

    public BorrowerServiceImpl(BorrowerRepository borrowerRepository) {
        super();
        this.borrowerRepository = borrowerRepository;
    }

    @Override
    public List<Borrower> getAllBorrowers() { return borrowerRepository.findAll();
    }

    @Override
    public Borrower saveBorrower(Borrower borrower) {
        return borrowerRepository.save(borrower);
    }

    @Override
    public Borrower getBorrowerById(Long id) {
        return borrowerRepository.findById(id).get();
    }

    @Override
    public Borrower updateBorrower(Borrower borrower) {
        return borrowerRepository.save(borrower);
    }

    @Override
    public void deleteBorrowerById(Long id) {
        borrowerRepository.deleteById(id);
    }

}

