package kg.edu.alatoo.midtermProject.service;

import kg.edu.alatoo.midtermProject.entity.Borrower;

import java.util.List;


public interface BorrowerService {
    List<Borrower> getAllBorrowers();

    Borrower saveBorrower(Borrower borrower);

    Borrower getBorrowerById(Long id);

    Borrower updateBorrower(Borrower borrower);

    void deleteBorrowerById(Long id);
}
