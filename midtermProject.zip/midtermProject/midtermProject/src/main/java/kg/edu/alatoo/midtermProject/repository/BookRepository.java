package kg.edu.alatoo.midtermProject.repository;

import kg.edu.alatoo.midtermProject.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{
}
